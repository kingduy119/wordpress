
<?php 
/**
 *
 * Template Name: KDI Fullwidth
 *
 * @package KDI Common
 */

get_header();
?>

<?php do_action( 'kdi_loop_content' ); ?>

<?php get_footer(); ?>