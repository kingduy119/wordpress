
<?php get_header() ?>

<div class="container text-center mt-5">
    <p class="fs-1 fw-bold">Oops! That page can&rsquo;t be found.</p>
    <a class="btn btn-primary" href="<?php bloginfo('url'); ?>">Back home page</a>
</div>
<!-- .container -->

<?php get_footer() ?>