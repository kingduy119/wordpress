
<?php get_header() ?>

<?php do_action( 'kdi_loop_content' ); ?>

<?php get_footer() ?>

