<ul id="list-archives">
    <?php wp_get_archives('type=monthly'); ?>
</ul>