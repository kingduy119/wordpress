
<span class="post--views">
    <a href="#">
        <i class="bi bi-eye"></i> <?php esc_html( kdi_get_postviews() ); ?>
    </a>
</span>


