
<span class="post--comment">
    <a href="<?php  ?>">
        <i class="bi bi-chat"></i> <?php esc_html( get_comments_number() ); ?>
    </a>
</span>
