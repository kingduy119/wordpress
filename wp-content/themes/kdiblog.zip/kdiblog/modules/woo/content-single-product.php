
<article id="product-<?php the_ID(); ?>" class="post pb-4">
    <div class="entry-content">
        <?php
        /**
         * woocommerce/content-single-product.php
         */
        the_content(); 
        ?>
    </div>
</article>