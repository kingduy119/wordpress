
<a href="<?php echo esc_url( get_permalink() ); ?>">
<img
    alt="Product thumbnail"
    class="product--thumbnail"
    src="<?php echo get_the_post_thumbnail_url( get_the_ID(), 'full' ); ?>"
>
</a>
