<?php
    global $product;
?>

<p class="product--price"><?php echo $product->get_price_html(); ?></p>



