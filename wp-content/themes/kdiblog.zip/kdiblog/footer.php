        
        
            </div> <!-- #page-content -->
        </div><!-- #page -->
        
        <footer class="page-footer">
        <?php 
            if( is_active_sidebar( 'page-footer' ) ) { dynamic_sidebar('page-footer');  }
        ?>
        </footer>
    
        <div id="fb-root"></div>
        <script async defer crossorigin="anonymous" src="https://connect.facebook.net/vi_VN/sdk.js#xfbml=1&version=v13.0&appId=927729581108661&autoLogAppEvents=1" nonce="6PAoSsq1"></script>

    <?php wp_footer(); ?>
</body>
</html>